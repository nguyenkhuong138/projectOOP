package com.example.controller;

import com.example.model.Station;
import com.example.service.StationService;
import java.util.List;

@RestController
@RequestMapping("/api/stations")
public class StationController {

    private final StationService stationService;

    public StationController(StationService stationService) {
        this.stationService = stationService;
    }

    @GetMapping("/nearby")
    public List<Station> getNearbyStations(
            @RequestParam double lat,
            @RequestParam double lng) {
        return stationService.findNearbyStations(lat, lng);
    }
}

package com.example.model;

public class BatteryInventory {
    private int stationId;
    private int available;
    private int charging;
    private int maintenance;

    public BatteryInventory() {}

    public BatteryInventory(int stationId, int available, int charging, int maintenance) {
        this.stationId = stationId;
        this.available = available;
        this.charging = charging;
        this.maintenance = maintenance;
    }

    public int getStationId() { return stationId; }
    public void setStationId(int stationId) { this.stationId = stationId; }

    public int getAvailable() { return available; }
    public void setAvailable(int available) { this.available = available; }

    public int getCharging() { return charging; }
    public void setCharging(int charging) { this.charging = charging; }

    public int getMaintenance() { return maintenance; }
    public void setMaintenance(int maintenance) { this.maintenance = maintenance; }
}

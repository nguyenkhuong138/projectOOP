package com.example.service;

import com.example.model.Station;

import java.util.ArrayList;
import java.util.List;

@Service
public class StationService {

    // Dữ liệu mô phỏng (thay cho database)
    private List<Station> stations = new ArrayList<>();

    public StationService() {
        stations.add(new Station(1, "Station A", "123 Lý Thường Kiệt", 10.776, 106.700, 5));
        stations.add(new Station(2, "Station B", "456 Nguyễn Văn Cừ", 10.758, 106.680, 2));
        stations.add(new Station(3, "Station C", "789 Điện Biên Phủ", 10.780, 106.690, 0));
    }

    // Hàm tính khoảng cách giữa hai điểm theo tọa độ lat/lng
    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371; // bán kính Trái Đất (km)
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2)
                 + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    // Tìm các trạm trong bán kính 5km và có pin sẵn
    public List<Station> findNearbyStations(double userLat, double userLng) {
        List<Station> result = new ArrayList<>();

        for (Station st : stations) {
            double d = distance(userLat, userLng, st.getLatitude(), st.getLongitude());
            if (d <= 5 && st.getAvailableBatteries() > 0) {
                result.add(st);
            }
        }
        return result;
    }

    public List<Station> getStations() {
        return stations;
    }
}
